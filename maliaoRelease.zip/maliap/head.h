#pragma once
#include <cmath>
#include <iostream>
#include "Utils.h"
#include <easyx.h>
using namespace std;