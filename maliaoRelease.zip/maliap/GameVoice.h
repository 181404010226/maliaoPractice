#pragma once


void GameMusic(int num);


void GameAudio(int num);