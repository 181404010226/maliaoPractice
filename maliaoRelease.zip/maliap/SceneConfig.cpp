#include "SceneConfig.h"

using namespace libxl;

Sceneconfig::Sceneconfig()
{
}

Sceneconfig* Sceneconfig::GetInstance()
{
	// ����ʽ
	static Sceneconfig m_Instance;
	return &m_Instance;
}


void Sceneconfig::LoadLevel(const wchar_t* fileName)
{
    Book* book = xlCreateXMLBook();
    if (book)
    {
        if (book->load(fileName))
        {
            levelSheet = book->getSheet(0);
        }
        else
        {
            std::cout << "����������·��:" << fileName << std::endl;
        }
    }
    // Ԥ������
    for (int i= 0; i < 20; i++) LoadObjects(i);
}

void Sceneconfig::LoadObjects(int column)
{
    if (!levelSheet) cout << "����!Ӧ���ȼ��ر���" << endl;
    for (int i = 0; i < 15; i++)
    {
        const wchar_t* s =levelSheet->readStr(i,column);
        if (s)
        {
            string check;
            Utils::Wchar_tToString(check, s);
            if (check == "��")
            {
                float edge = CellWidth;
                CreateObject<testCube>(Utils::Rect{ (float)column * edge,(float)i * edge,edge-5,edge });
            }
            if (check == "��")
            {
                float edge = CellWidth;
                CreateObject<Grass>(Utils::Rect{ (float)column * edge,(float)i * edge + 24,edge,36 });
            }
            if (check == "��")
            {
                float edge = CellWidth;
                CreateObject<Tree>(Utils::Rect{ (float)column * edge,(float)i * edge - 9,edge,69 });
            }
            if (check == "��")
            {
                float edge = CellWidth;
                CreateObject<House>(Utils::Rect{ (float)column * edge,(float)i * edge - 13,edge,73 });
            }
            if (check == "�����ͼ")
            {
                float edge = CellWidth;
                CreateObject<Wmap>(Utils::Rect{ (float)column * edge,(float)i * edge,360,288 });
            }
            if (check == "��")
            {
                float edge = CellWidth;
                CreateObject<Cloud>(Utils::Rect{ (float)column * edge,(float)i * edge+24,60,36 });
            }
        }   
    }
}
