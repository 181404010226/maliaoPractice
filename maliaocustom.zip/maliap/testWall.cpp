#include "testWall.h"

testWall::testWall()
{
}

void testWall::onCrash(MonoObject* collider)
{
}

void testWall::onGroud(MonoObject* collider)
{
}

void testWall::onFrameUpdate()
{
}

void testWall::onMoveSuccess()
{
}
